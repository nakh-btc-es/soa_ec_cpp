//
// Third Party Support License -- for use only to support products
// interfaced to MathWorks software under terms specified in your
// company's restricted use license agreement.
//
// File: aT.h
//
// Code generated for Simulink model 'SOA_demo_codegen'.
//
// Model version                  : 1.3
// Simulink Coder version         : 9.8 (R2022b) 13-May-2022
// C/C++ source code generated on : Mon Oct 13 13:41:43 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//

#ifndef RTW_HEADER_aT_h_
#define RTW_HEADER_aT_h_
#include "rtwtypes.h"

class aT
{
 public:
  virtual void f(real_T, real_T *)
  {
  }

  virtual ~aT()
    = default;
};

#endif                                 // RTW_HEADER_aT_h_

//
// File trailer for generated code.
//
// [EOF]
//
